package org.example.service;

import org.example.model.Student;
import java.util.List;

public interface StudentService {
  // 创建学生
  void createStudent(Student student);

  // 通过ID查询学生
  Student getStudentById(Long id);

  // 查询所有学生
  List<Student> getAllStudents();

  // 更新学生信息
  void updateStudent(Student student);

  // 删除学生
  void deleteStudent(Long id);
}