package org.example.dao;

import org.example.model.Student;
import java.util.List;

public interface StudentDAO {
  // 创建学生
  void save(Student student);

  // 通过ID查询学生
  Student findById(Long id);

  // 查询所有学生
  List<Student> findAll();

  // 更新学生信息
  void update(Student student);

  // 删除学生
  void delete(Long id);
}