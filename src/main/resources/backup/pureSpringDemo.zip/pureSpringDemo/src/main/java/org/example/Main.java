package org.example;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
  public static void main(String[] args) {
    // 启动Spring容器
    ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("spring/applicationContext.xml");
    System.out.println("Spring应用启动成功！");

    // 关闭容器
//    context.close();
  }
}


