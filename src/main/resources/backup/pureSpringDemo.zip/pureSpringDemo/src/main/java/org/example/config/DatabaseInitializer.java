package org.example.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.stream.Collectors;

@Component
public class DatabaseInitializer implements ApplicationListener<ContextRefreshedEvent> {

  private final JdbcTemplate jdbcTemplate;
  private boolean initialized = false;

  @Autowired
  public DatabaseInitializer(JdbcTemplate jdbcTemplate) {
    this.jdbcTemplate = jdbcTemplate;
  }

  @Override
  public void onApplicationEvent(ContextRefreshedEvent event) {
    if (!initialized) {
      try {
        // 读取SQL文件
        ClassPathResource resource = new ClassPathResource("sql/init.sql");
        String sql = new BufferedReader(
            new InputStreamReader(resource.getInputStream(), StandardCharsets.UTF_8))
            .lines()
            .collect(Collectors.joining("\n"));

        // 执行SQL语句
        jdbcTemplate.execute(sql);

        System.out.println("数据库已使用SQL脚本初始化");
        initialized = true;
      } catch (Exception e) {
        System.err.println("数据库初始化失败: " + e.getMessage());
        e.printStackTrace();
      }
    }
  }
}