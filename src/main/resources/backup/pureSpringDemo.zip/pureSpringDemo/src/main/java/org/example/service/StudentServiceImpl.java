package org.example.service;

import org.example.dao.StudentDAO;
import org.example.model.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class StudentServiceImpl implements StudentService {

  private final StudentDAO studentDAO;

  @Autowired
  public StudentServiceImpl(StudentDAO studentDAO) {
    this.studentDAO = studentDAO;
  }

  @Override
  public void createStudent(Student student) {
    studentDAO.save(student);
  }

  @Override
  @Transactional(readOnly = true)
  public Student getStudentById(Long id) {
    return studentDAO.findById(id);
  }

  @Override
  @Transactional(readOnly = true)
  public List<Student> getAllStudents() {
    return studentDAO.findAll();
  }

  @Override
  public void updateStudent(Student student) {
    studentDAO.update(student);
  }

  @Override
  public void deleteStudent(Long id) {
    studentDAO.delete(id);
  }
}