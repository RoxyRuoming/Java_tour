package org.example.dao;

import org.example.model.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;

@Repository
public class StudentDAOImpl implements StudentDAO {

  private final JdbcTemplate jdbcTemplate;

  @Autowired
  public StudentDAOImpl(JdbcTemplate jdbcTemplate) {
    this.jdbcTemplate = jdbcTemplate;
  }

  private final RowMapper<Student> rowMapper = (ResultSet rs, int rowNum) -> {
    Student student = new Student();
    student.setId(rs.getLong("id"));
    student.setName(rs.getString("name"));
    student.setAge(rs.getInt("age"));
    return student;
  };

  @Override
  public void save(Student student) {
    String sql = "INSERT INTO students (name, age) VALUES (?, ?) RETURNING id";
    Long id = jdbcTemplate.queryForObject(sql, Long.class, student.getName(), student.getAge());
    if (id != null) {
      student.setId(id);
    }
  }

  @Override
  public Student findById(Long id) {
    String sql = "SELECT * FROM students WHERE id = ?";
    List<Student> students = jdbcTemplate.query(sql, rowMapper, id);
    return students.isEmpty() ? null : students.get(0);
  }

  @Override
  public List<Student> findAll() {
    String sql = "SELECT * FROM students";
    return jdbcTemplate.query(sql, rowMapper);
  }

  @Override
  public void update(Student student) {
    String sql = "UPDATE students SET name = ?, age = ? WHERE id = ?";
    jdbcTemplate.update(sql, student.getName(), student.getAge(), student.getId());
  }

  @Override
  public void delete(Long id) {
    String sql = "DELETE FROM students WHERE id = ?";
    jdbcTemplate.update(sql, id);
  }
}