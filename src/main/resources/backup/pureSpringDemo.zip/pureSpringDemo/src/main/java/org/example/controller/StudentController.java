package org.example.controller;

import org.example.model.Student;
import org.example.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/students")
public class StudentController {

  private final StudentService studentService;

  @Autowired
  public StudentController(StudentService studentService) {
    this.studentService = studentService;
    System.out.println("======================================================");
    System.out.println("StudentController已初始化 - " + new java.util.Date());
    System.out.println("RequestMapping路径: /students");
    System.out.println("======================================================");
  }

  //  http://localhost:8080/students
  @GetMapping
  public ResponseEntity<List<Student>> getAllStudents() {
    System.out.println("======================================================");
    System.out.println("收到获取所有学生的请求 - " + new java.util.Date());
    System.out.println("======================================================");

    List<Student> students = studentService.getAllStudents();
    return new ResponseEntity<>(students, HttpStatus.OK);
  }

  @GetMapping("/{id}")
  public ResponseEntity<Student> getStudent(@PathVariable Long id) {
    Student student = studentService.getStudentById(id);
    if (student == null) {
      return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
    return new ResponseEntity<>(student, HttpStatus.OK);
  }

  @PostMapping
  public ResponseEntity<Student> createStudent(@RequestBody Student student) {
    studentService.createStudent(student);
    return new ResponseEntity<>(student, HttpStatus.CREATED);
  }

  @PutMapping("/{id}")
  public ResponseEntity<Student> updateStudent(@PathVariable Long id, @RequestBody Student student) {
    Student existingStudent = studentService.getStudentById(id);
    if (existingStudent == null) {
      return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    student.setId(id);
    studentService.updateStudent(student);
    return new ResponseEntity<>(student, HttpStatus.OK);
  }

  @DeleteMapping("/{id}")
  public ResponseEntity<Void> deleteStudent(@PathVariable Long id) {
    Student existingStudent = studentService.getStudentById(id);
    if (existingStudent == null) {
      return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    studentService.deleteStudent(id);
    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
  }
}